Milestone 2

Ryan Stanley
Arif Topcu
Swana Weng

Division of Work:

        Manual Labor/Data Collection:                   Arif
        Reading Documentation/Leading Discussion:       Swana
        Peer Programming:                               All

Classifier Used:

        J48 -C 0.25 -M 2

Detailed Accuracy By Class:

        TP Rate          FP Rate   Precision   Recall    F-Measure   ROC Area   Class
        0.938            0.007     0.984       0.938     0.96        0.958      jumping
        1                0.016     0.973       1         0.986       0.989      stationary
        0.952            0.029     0.937       0.952     0.944       0.95       walking
        Weighted Avg.    0.965     0.017       0.965     0.965       0.965      0.967

More details as printed from Weka can be found in ActivityClassifier.java